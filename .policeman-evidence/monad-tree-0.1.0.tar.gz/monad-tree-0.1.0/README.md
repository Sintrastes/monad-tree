# monad-tree

This package provides monad instances for a rose-tree-like data structure, allowing for the definition of non-deterministic computations that do not depend on a specific search procedure.

For more information, see the documentation for the main Control.Monad.Tree module.

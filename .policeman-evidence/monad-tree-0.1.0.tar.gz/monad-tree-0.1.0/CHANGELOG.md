# Revision history for monad-tree

## 0.1.0 -- 2021-08-20

  * First version. Added Tree definition, instances, and basic tree traversals.
